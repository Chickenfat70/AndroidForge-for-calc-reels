package com.example.calcreels

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlin.math.abs
import java.text.DecimalFormat

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private var player: ExoPlayer? = null
    private var videoMode = false
    private var videoIndex = 0
    private var swipeStartX = 0f
    private var swipeStartY = 0f

    // Demo clips show the built-in vertical feed. Internet access is required.
    private val videoUrls = listOf(
        "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
        "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
        "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
        "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4",
        "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMobstercast.mp4"
    )

    private lateinit var display: TextView
    private var currentInput = "0"
    private var storedValue: Double? = null
    private var pendingOperator: String? = null
    private var startNewNumber = true
    private var lastWasEquals = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(245, 245, 245)
        window.navigationBarColor = Color.rgb(245, 245, 245)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        root = FrameLayout(this)
        root.setBackgroundColor(Color.rgb(250, 250, 250))
        setContentView(root)
        showCalculator()
    }

    private fun showCalculator() {
        videoMode = false
        player?.pause()
        root.removeAllViews()
        root.setBackgroundColor(Color.rgb(250, 250, 250))

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(4))
            setBackgroundColor(Color.rgb(250, 250, 250))
        }
        root.addView(page, FrameLayout.LayoutParams(-1, -1))

        val header = TextView(this).apply {
            text = "Calculator"
            textSize = 20f
            setTextColor(Color.rgb(40, 40, 40))
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(8), dp(4), dp(8))
        }
        page.addView(header, LinearLayout.LayoutParams(-1, dp(48)))

        display = TextView(this).apply {
            text = currentInput
            textSize = 48f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setTextColor(Color.rgb(25, 25, 25))
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            maxLines = 1
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        page.addView(display, LinearLayout.LayoutParams(-1, 0, 1f))

        val rows = listOf(
            listOf("AC", "+/-", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "−"),
            listOf("1", "2", "3", "+"),
            listOf("⌫", "0", ".", "=")
        )
        rows.forEach { labels ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            labels.forEach { label ->
                val isOperator = label in listOf("÷", "×", "−", "+", "=")
                val isUtility = label in listOf("AC", "+/-", "%", "⌫")
                val bg = when {
                    label == "=" -> Color.rgb(66, 133, 244)
                    isOperator -> Color.rgb(232, 240, 254)
                    isUtility -> Color.rgb(232, 234, 237)
                    else -> Color.WHITE
                }
                val fg = if (label == "=") Color.WHITE else Color.rgb(35, 35, 35)
                val button = Button(this).apply {
                    text = label
                    textSize = if (label.length > 1) 18f else 23f
                    setTextColor(fg)
                    backgroundTintList = android.content.res.ColorStateList.valueOf(bg)
                    isAllCaps = false
                    stateListAnimator = null
                    setOnClickListener { onCalculatorButton(label) }
                }
                val params = LinearLayout.LayoutParams(0, dp(64), 1f).apply {
                    setMargins(dp(4), dp(4), dp(4), dp(4))
                }
                row.addView(button, params)
            }
            page.addView(row, LinearLayout.LayoutParams(-1, dp(72)))
        }

        val hint = TextView(this).apply {
            text = "Swipe up for videos"
            textSize = 12f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(8))
        }
        page.addView(hint, LinearLayout.LayoutParams(-1, dp(28)))
        refreshDisplay()
    }

    private fun onCalculatorButton(label: String) {
        when (label) {
            "AC" -> {
                currentInput = "0"
                storedValue = null
                pendingOperator = null
                startNewNumber = true
                lastWasEquals = false
            }
            "+/-" -> {
                val value = currentInput.toDoubleOrNull() ?: 0.0
                currentInput = formatNumber(-value)
                startNewNumber = false
            }
            "%" -> {
                val value = currentInput.toDoubleOrNull() ?: 0.0
                currentInput = formatNumber(value / 100.0)
                startNewNumber = false
            }
            "⌫" -> {
                currentInput = if (currentInput.length <= 1 ||
                    (currentInput.length == 2 && currentInput.startsWith("-"))) "0"
                    else currentInput.dropLast(1)
                startNewNumber = false
            }
            "+", "−", "×", "÷" -> {
                val value = currentInput.toDoubleOrNull() ?: 0.0
                if (storedValue != null && pendingOperator != null && !startNewNumber) {
                    val result = calculate(storedValue!!, value, pendingOperator!!)
                    if (result == null) {
                        showError()
                        return
                    }
                    currentInput = formatNumber(result)
                    storedValue = result
                } else {
                    storedValue = value
                }
                pendingOperator = label
                startNewNumber = true
                lastWasEquals = false
            }
            "=" -> {
                val first = storedValue
                val op = pendingOperator
                val second = currentInput.toDoubleOrNull()
                if (first != null && op != null && second != null) {
                    val result = calculate(first, second, op)
                    if (result == null) {
                        showError()
                        return
                    }
                    currentInput = formatNumber(result)
                    storedValue = null
                    pendingOperator = null
                    startNewNumber = true
                    lastWasEquals = true
                }
            }
            "." -> {
                if (startNewNumber) currentInput = "0."
                else if (!currentInput.contains(".")) currentInput += "."
                startNewNumber = false
                lastWasEquals = false
            }
            else -> {
                if (startNewNumber || currentInput == "0" || lastWasEquals) {
                    currentInput = label
                    if (lastWasEquals) {
                        storedValue = null
                        pendingOperator = null
                    }
                } else if (currentInput.length < 14) {
                    currentInput += label
                }
                startNewNumber = false
                lastWasEquals = false
            }
        }
        refreshDisplay()
    }

    private fun calculate(a: Double, b: Double, op: String): Double? {
        val result = when (op) {
            "+" -> a + b
            "−" -> a - b
            "×" -> a * b
            "÷" -> if (b == 0.0) return null else a / b
            else -> b
        }
        return if (result.isFinite()) result else null
    }

    private fun formatNumber(value: Double): String {
        if (value == 0.0) return "0"
        return if (abs(value) < 1e12) DecimalFormat("0.##########").format(value) else value.toString()
    }

    private fun refreshDisplay() {
        if (::display.isInitialized) display.text = currentInput
    }

    private fun showError() {
        currentInput = "Error"
        storedValue = null
        pendingOperator = null
        startNewNumber = true
        refreshDisplay()
        Toast.makeText(this, "Cannot divide by zero or calculate this result", Toast.LENGTH_SHORT).show()
    }

    private fun showVideos() {
        videoMode = true
        root.removeAllViews()
        root.setBackgroundColor(Color.BLACK)

        val frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(frame, FrameLayout.LayoutParams(-1, -1))

        val pv = PlayerView(this).apply {
            useController = true
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            setBackgroundColor(Color.BLACK)
        }
        frame.addView(pv, FrameLayout.LayoutParams(-1, -1))

        val topLabel = TextView(this).apply {
            text = "SHORT VIDEOS  ⋮"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setShadowLayer(5f, 1f, 1f, Color.BLACK)
        }
        frame.addView(topLabel, FrameLayout.LayoutParams(-1, dp(60), Gravity.TOP))

        val bottomHint = TextView(this).apply {
            text = "Swipe ↑ next video     Swipe ↓ calculator"
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setShadowLayer(5f, 1f, 1f, Color.BLACK)
            setPadding(dp(8), dp(12), dp(8), dp(18))
        }
        frame.addView(bottomHint, FrameLayout.LayoutParams(-1, dp(56), Gravity.BOTTOM))

        if (player == null) {
            player = ExoPlayer.Builder(this).build().apply {
                repeatMode = Player.REPEAT_MODE_ONE
                playWhenReady = true
            }
        }
        pv.player = player
        playCurrentVideo()
    }

    private fun playCurrentVideo() {
        val p = player ?: return
        p.setMediaItem(MediaItem.fromUri(videoUrls[videoIndex]))
        p.prepare()
        p.playWhenReady = true
    }

    // Activity-level detection lets swipes work over buttons and the video player.
    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                swipeStartX = event.rawX
                swipeStartY = event.rawY
            }
            MotionEvent.ACTION_UP -> {
                val dx = event.rawX - swipeStartX
                val dy = event.rawY - swipeStartY
                val threshold = dp(90).toFloat()
                if (abs(dy) > threshold && abs(dy) > abs(dx) * 1.25f) {
                    if (!videoMode && dy < 0) {
                        showVideos()
                        return true
                    } else if (videoMode && dy < 0) {
                        videoIndex = (videoIndex + 1) % videoUrls.size
                        playCurrentVideo()
                        return true
                    } else if (videoMode && dy > 0) {
                        showCalculator()
                        return true
                    }
                }
            }
        }
        return super.dispatchTouchEvent(event)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (videoMode) showCalculator() else super.onBackPressed()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
