# CalcReels — Android Studio project

A small Android app that starts as a working, standard-style calculator. Swipe **up** anywhere on the calculator to open a vertical short-video feed. Swipe **up** in video mode to advance to the next clip; swipe **down** to return to the calculator.

## What is included

- Native Android app written in Kotlin.
- Calculator buttons for digits, decimals, addition, subtraction, multiplication, division, percent, sign toggle, clear, backspace, and equals.
- Built-in video-feed screen using AndroidX Media3 / ExoPlayer.
- Five sample MP4 streams to demonstrate the feed.

## Important note about the videos

The app contains the feed interface and a list of public sample video URLs, not a bundled library of social-media Reels. An internet connection is required, and these demo URLs may change or become unavailable. The app does not scrape Instagram or YouTube. To use your own clips, replace the URLs in `MainActivity.kt` with direct MP4/HLS video URLs you have permission to use. For fully offline playback, add licensed video files under `app/src/main/assets/` and update the player to load those local assets.

## Build the APK

### Option A — Android Studio (recommended)

1. Install Android Studio from https://developer.android.com/studio.
2. Open Android Studio and choose **Open**.
3. Select the unzipped `CalcReelsAndroid` folder (the one containing `settings.gradle`).
4. Allow Gradle sync to finish. If prompted, install Android SDK Platform 35 and JDK 17.
5. To test it, connect an Android phone with USB debugging enabled, or create an emulator, then press **Run**.
6. To build an installable debug APK, choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
7. Android Studio will show a notification with a link to the APK. Usually it is at:
   `app/build/outputs/apk/debug/app-debug.apk`

### Option B — command line

Install Android Studio / Android SDK and a JDK 17 first. From the project folder, run:

```bash
gradle assembleDebug
```

If you have a local Gradle installation, this creates:
`app/build/outputs/apk/debug/app-debug.apk`

This project does not bundle the Gradle wrapper JAR. Android Studio can import and build it directly; alternatively, generate a wrapper from an installed Gradle version by running `gradle wrapper --gradle-version 8.9`.

## Install on your Android phone

1. Transfer `app-debug.apk` to your phone.
2. Tap the APK in Files / Downloads.
3. If Android asks, allow your file manager to **Install unknown apps**.
4. Confirm **Install** and launch **Calculator**.

For USB installation from a computer with Android Platform Tools installed:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## Controls

- Calculator screen: use the keypad normally.
- Swipe upward: enter the video feed.
- Video feed: swipe upward to play the next clip.
- Swipe downward: return to the calculator.
- Android Back button: return to the calculator from video mode.

## Troubleshooting

- **Videos are black or do not load:** check internet access and try again. Sample video hosting is external to the app.
- **Gradle sync fails:** confirm JDK 17 is selected in Android Studio and Android SDK Platform 35 is installed.
- **APK will not install:** build a debug APK using Android Studio and ensure the phone's Android version is Android 6.0 or newer.


Video source note: the original Google Cloud sample URLs returned AccessDenied, so this version uses public demo MP4 URLs from MDN, test-videos.co.uk, W3C, W3Schools, and SampleFiles. Internet access is required for playback.


## Instagram Reels mode

Swipe up from the calculator to load Instagram's real Reels website (`https://www.instagram.com/reels/`) in an Android WebView. Instagram may require sign-in, may show compatibility/login prompts, and controls which content and playback features work in an embedded browser. The app does not scrape Instagram or bypass login/access controls. Use the on-screen “‹ Calculator” button or Android Back to return to the calculator. Swipes within Instagram are left to Instagram so its feed can scroll normally.
